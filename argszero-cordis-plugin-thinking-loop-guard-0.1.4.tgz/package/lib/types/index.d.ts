/**
 * Thinking-loop guard for the dsh harness.
 *
 * Closes a guard-layer gap the in-tree `guard/` family does not cover.
 * `guard/timeout-policy` is a per-tool `tools/execute` deadline and
 * `guard/repeat-tool-reminder` is a same-tool-call chain detector — only a tool
 * *call* arms either. When a model degrades into a pure-thinking loop
 * (`deepseek-v4.1-flash-expires-on-0910` under `max`/`high` reasoning effort and
 * a long context), it emits only `reasoning-delta` chunks — zero `text-delta`,
 * zero `tool-call-delta` — so neither fires, `turn()` never sets `turnEnds`, and
 * the agent-loop `while (true)` never breaks until the user manually aborts.
 *
 * This plugin observes the public `llm/stream` waterfall (present on dsh
 * **0.1.2-rc.1 and 0.1.5-alpha.1**), tallies the `StreamChunk` composition of
 * each loop-built model call, and escalates through a configured reaction.
 *
 * Why `llm/stream` and not `agent/assistant-stream`: the latter (scoped emit
 * with `start`/`chunk`/`end` frames) only exists from dsh 0.1.5-alpha.1; the
 * widely-installed 0.1.2-rc.1 has neither it nor `AssistantStreamFrame`, so a
 * plugin pinned to that seam silently no-ops on the common release. `llm/stream`
 * is a Cordis waterfall around every streaming model call in both versions and
 * carries the same `StreamChunk` delta types, and its `GenerateOptions` carries
 * `sessionId`, from which the live Agent is reachable via `ctx.agents.get(...)`.
 *
 * ## Detection (three shapes, because one does not cover the loop)
 *
 * Issue #1's re-test on dsh 0.1.2-rc.1 showed the v0.1.2 detector did not fire on
 * the reproduction: the loop recurred with the plugin loaded and working. The
 * v0.1.2 detector had two blind spots that together miss the reported shape:
 *
 *  1. It required **consecutive** reasoning-only calls and reset the counter on
 *     *any* text output. A loop whose steps each emit some (boilerplate) text
 *     after their reasoning never accumulates, because every step looks like
 *     progress.
 *  2. Its only content signal was `repeatRatio` — verbatim n-gram repetition
 *     *within one call*. A model that re-derives the same stalled conclusion with
 *     different wording every step scores near zero on that measure, so it also
 *     slipped through.
 *
 * This version keeps the intra-call measure and adds a cross-call one: the
 * **containment** of the previous call's distinct n-grams in this call's. A step
 * is "stalled" when it either produced no output at all (shape 1) *or* it repeats
 * most of the previous step's distinct reasoning material (shape 2 — the same
 * conclusion reworded, which is what a stuck model actually does). Anything else
 * is genuine progress and resets the run.
 *
 * ## Reaction
 *
 * On a threshold crossing it applies `escalate`. Unlike v0.1.2 it does **not**
 * latch after one reaction: a single steer often does not break a strong loop
 * (which is exactly what issue #1's re-test observed), so the run counter resets
 * and re-fires after another `maxThinkingSteps`, up to `maxFires` times.
 *
 * Mechanism notes (verified against packages/core/agent-loop/src/agent.ts,
 * packages/llm/llm/src/index.ts, and packages/core/agent/src/runtime-types.ts on
 * dsh 0.1.5-alpha.1; the `llm/stream` / `StreamChunk` / `ctx.agents.get` trio is
 * present unchanged on 0.1.2-rc.1):
 *  - `llm/stream` is a waterfall; a listener wraps `next()` and sees each chunk.
 *  - `chunk: StreamChunk` distinguishes `reasoning-delta` / `text-delta` /
 *    `tool-call-delta` (packages/llm/llm/src/types.ts).
 *  - Loop-built requests carry `markAgentLoopRequest`; `isAgentLoopRequest`
 *    filters out arbitrary non-agent streaming (tool streams, etc.).
 *  - `options.sessionId` → `ctx.agents.get(sessionId)` yields the live `Agent`.
 *  - `agent.steer(message)`, `agent.inject(message)`, and `agent.cancel(cause)`
 *    are public methods; a listener can react but not veto an in-flight step.
 *
 * @module @argszero/cordis-plugin-thinking-loop-guard
 */
import { Context } from '@deepseek-ai/cordis';
import z from '@deepseek-ai/schemastery';
/** Plugin configuration. */
export interface Config {
    /**
     * Consecutive stalled model calls before a reaction. A call is stalled when it
     * produced no text/tool output, or when it repeated most of the previous
     * call's distinct reasoning material. Default `3`.
     */
    maxThinkingSteps?: number;
    /**
     * Minimum reasoning text within one call before that call is judged at all; a
     * short burst is normal. Default `2048` chars.
     */
    minReasoningChars?: number;
    /**
     * Intra-call low-entropy ratio: coverage of one call's reasoning text by
     * repeated fixed-length grams. Language-agnostic (handles CJK with no
     * whitespace): a degenerate "好。执行。" loop is near 1.0; coherent exploration
     * is low. Only consulted once `minReasoningChars` is met. Default `0.5`.
     */
    repeatRatio?: number;
    /**
     * Cross-call similarity: how much of the previous call's distinct reasoning
     * material must reappear in this call before the call counts as a repetition
     * of stalled thinking rather than progress. `1.0` requires an exact rerun of
     * the same material; `0` disables this signal. Default `0.8`.
     */
    similarityThreshold?: number;
    /**
     * Reaction to fire on a threshold crossing. `warn` injects a notice, `steer`
     * sends a steering message, `cancel` hard-aborts the turn. Default `steer`.
     */
    escalate?: 'warn' | 'steer' | 'cancel';
    /**
     * How many times one agent may be reacted to before the guard stops
     * re-firing. A single intervention often does not break a strong loop, so the
     * default allows several. Default `4`.
     */
    maxFires?: number;
    /** Cancel cause used when `escalate` is `cancel`. Default `'thinking-loop'`. */
    cancelCause?: string;
}
/** Resolved config: every field carries its validated default. */
type ResolvedConfig = Required<Config>;
export declare const Config: z<Config>;
export declare const name = "thinking-loop-guard";
/**
 * Cordis services this plugin resolves off the Context.
 *
 * Declaring `agents` is REQUIRED, not documentation: Cordis's context proxy
 * throws `cannot get property "agents" without inject` for any service read
 * that the fiber did not declare (vendor/cordis/src/reflect.ts, the
 * `waterfall('internal/get', …)` guard). The plugin reaches the live Agent via
 * `ctx.agents.get(options.sessionId)`, so without this line `apply()` throws on
 * activation and every session in that deployment fails to run.
 *
 * TypeScript cannot catch this: `ctx.agents` type-checks as soon as
 * `@deepseek-ai/dsh-agent` is in the type graph, because the guard is purely
 * runtime. That is exactly how v0.1.1 shipped broken (issue #1).
 */
export declare const inject: string[];
/** Fixed window used for both the intra-call and cross-call measures. */
export declare const GRAM_SIZE = 4;
/**
 * The distinct fixed-length grams of one reasoning text.
 *
 * Fixed-length windows are the language-agnostic choice: CJK loops
 * ("好。执行。") have no whitespace, so a whitespace-token histogram collapses to
 * one token and can never distinguish repetition.
 *
 * @param text - the reasoning text of one call.
 * @param size - the window length in characters.
 * @returns the set of distinct windows (empty for text shorter than `size`).
 */
export declare function grams(text: string, size?: number): Set<string>;
/**
 * Low-entropy ratio: coverage of one text by repeated fixed-length grams.
 *
 * A tight repetition ("好。执行。" x N) scores near 1.0 while coherent reasoning
 * (which rarely repeats a window verbatim) scores near 0.
 *
 * @param reasoning - the reasoning text of one call.
 * @returns the fraction of windows that had already appeared in the same text.
 */
export declare function repeatRatio(reasoning: string): number;
/**
 * Containment of one gram set in another: the fraction of the SMALLER set's
 * grams present in the larger.
 *
 * Containment rather than Jaccard on purpose. A stuck model typically restates
 * the previous step's material and appends another sentence, so the new set is a
 * near-superset of the old one; Jaccard would dilute that with the new material
 * and let the step look like progress, while containment reports the repetition
 * directly.
 *
 * @param a - one call's distinct grams.
 * @param b - another call's distinct grams.
 * @returns `0` when either set is empty, otherwise the containment in `[0, 1]`.
 */
export declare function containment(a: ReadonlySet<string>, b: ReadonlySet<string>): number;
/** What one completed model call looked like to the guard. */
export interface StepObservation {
    /** Whether the call emitted any `text-delta` or `tool-call-delta`. */
    readonly hasOutput: boolean;
    /** The call's total reasoning text. */
    readonly reasoning: string;
}
/** Why one call was counted as stalled (`undefined` = it was progress). */
export type StallReason = 'reasoning-only' | 'repeated-material' | 'low-entropy';
/**
 * The per-agent detector: accumulates stalled calls and decides when to react.
 *
 * Kept free of Cordis types so the decision rule is unit-testable without a
 * harness: the plugin only feeds it observations and applies the reaction.
 */
export declare class LoopDetector {
    private readonly config;
    private stalled;
    private fires;
    private previous;
    private lastReason;
    /**
     * @param config - the resolved plugin configuration.
     */
    constructor(config: ResolvedConfig);
    /** The stalled-run length that would trigger the next reaction. */
    get threshold(): number;
    /** How many reactions have fired for this agent so far. */
    get fired(): number;
    /**
     * Observe one completed model call.
     *
     * @param step - the call's output shape and reasoning text.
     * @returns the reason it counted as stalled, or `undefined` when it was progress.
     */
    observe(step: StepObservation): StallReason | undefined;
    /**
     * Whether a reaction is due now, consuming one fire when it is.
     *
     * A single intervention often does not break a strong loop, so a fire resets
     * the run counter (another full run of stalled calls is needed) and is capped
     * by `maxFires` so the guard cannot intervene forever.
     *
     * @returns the reason to report in the reaction, or `undefined` when no reaction is due.
     */
    takeFire(): StallReason | undefined;
    /** Forget every observation (used when a loop is judged broken by real output). */
    reset(): void;
}
/**
 * Install the listener. Per-`Agent` state is keyed in a `WeakMap` so a disposed
 * agent is collected; detectors are scoped to one agent lifecycle.
 */
export declare function apply(ctx: Context, config: ResolvedConfig): void;
export {};
